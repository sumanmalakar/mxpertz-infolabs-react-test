import React from 'react'

const GalaryImg = ({img}) => {
  return (
    <>
    <div className="img">
        <img src={img} alt="img" />
    </div>
    </>
  )
}

export default GalaryImg