import React from 'react'

const Home = () => {
  return (
    <>
    <div className='home-flex'>
        <div className="left">
            <div className="size">
                OUR STORY
              
                <div className="border-bottom"></div>
            </div>
            <h3>Welcome To Royal</h3>
            <div className="size">

            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet beatae exercitationem, officia ipsam laboriosam modi eligendi architecto at id non.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet beatae exercitationem, officia ipsam laboriosam modi eligendi architecto at id non.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet beatae exercitationem, officia ipsam laboriosam modi eligendi architecto at id non.
            </p>
            <br />
            {/* <br /> */}
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet beatae exercitationem, officia ipsam laboriosam modi eligendi architecto at id non.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet beatae exercitationem, officia ipsam laboriosam modi eligendi architecto at id non.
                </p>
            </div>
        </div>
        <div className="right">
           <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiPHPfcV5KV8XOpGWBPNLr16gVIzoqpuKPAw&usqp=CAU" alt="img" />
        </div>
    </div>
    </>
  )
}

export default Home