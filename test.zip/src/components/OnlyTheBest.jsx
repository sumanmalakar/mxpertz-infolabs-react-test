import React from 'react'

const OnlyTheBest = () => {
  return (
    <>
    <div className="only_the_best">
          <div className="container-fluid">

        <div>

    <p className='size'>
        ONLY THE BEST

    </p>
    <div className="border-bottom"></div>
        </div>


    <h2 >Fresh Ingredient, Tasty Meals</h2>

    <p className='size'>
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Corrupti exercitationem molestiae tenetur quaerat beatae, illum non minima modi repudiandae nemo.
    </p>

    <button className='btn'>VIEW ITEMS</button>
    </div>
    </div>
    </>
  )
}

export default OnlyTheBest